@Composable
fun SideDishMenuScreen(
    onNext: () -> Unit,
    onCancel: () -> Unit
) {
    Column {
        Text("Choose a Side Dish")
        Button(onClick = onNext) {
            Text("Next: Accompaniment")
        }
        Button(onClick = onCancel) {
            Text("Cancel Order")
        }
    }
}
