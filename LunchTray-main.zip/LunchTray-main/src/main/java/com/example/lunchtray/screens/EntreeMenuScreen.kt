@Composable
fun EntreeMenuScreen(
    onNext: () -> Unit,
    onCancel: () -> Unit
) {
    Column {
        Text("Choose an Entree")
        Button(onClick = onNext) {
            Text("Next: Side Dish")
        }
        Button(onClick = onCancel) {
            Text("Cancel Order")
        }
    }
}
