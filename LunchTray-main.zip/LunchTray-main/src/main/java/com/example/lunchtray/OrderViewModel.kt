class OrderViewModel : ViewModel() {
    var entree: String? by mutableStateOf(null)
    var sideDish: String? by mutableStateOf(null)
    var accompaniment: String? by mutableStateOf(null)

    fun resetOrder() {
        entree = null
        sideDish = null
        accompaniment = null
    }
}
