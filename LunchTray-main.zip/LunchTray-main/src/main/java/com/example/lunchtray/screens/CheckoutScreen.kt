@Composable
fun CheckoutScreen(
    onSubmit: () -> Unit,
    onCancel: () -> Unit
) {
    Column {
        Text("Order Summary")
        Button(onClick = onSubmit) {
            Text("Submit Order")
        }
        Button(onClick = onCancel) {
            Text("Cancel Order")
        }
    }
}
