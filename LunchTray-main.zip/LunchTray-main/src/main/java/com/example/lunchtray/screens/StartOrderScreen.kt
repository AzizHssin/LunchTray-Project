@Composable
fun StartOrderScreen(onStartOrder: () -> Unit) {
    Column {
        Text("Welcome to Lunch Tray!")
        Button(onClick = onStartOrder) {
            Text("Start Order")
        }
    }
}
