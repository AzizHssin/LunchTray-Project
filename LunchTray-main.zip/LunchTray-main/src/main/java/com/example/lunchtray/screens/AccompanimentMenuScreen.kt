@Composable
fun AccompanimentMenuScreen(
    onNext: () -> Unit,
    onCancel: () -> Unit
) {
    Column {
        Text("Choose an Accompaniment")
        Button(onClick = onNext) {
            Text("Next: Checkout")
        }
        Button(onClick = onCancel) {
            Text("Cancel Order")
        }
    }
}
